#include "sacredBird.h"

int SacredBird::hit()
{
	kill();
	return -10;
}
