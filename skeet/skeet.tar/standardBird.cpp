#include "standardBird.h"

int StandardBird::hit()
{
	kill();
	return 1;
}
