/***********************************************************************
* Header File:
*    Lander : Things related to the state of the lander
* Author:
*    Alec Otterson
* Summary:
*    Everything we need to know about the lander.
************************************************************************/

#pragma once

#include <iostream>
#include "point.h"
#include "velocity.h"
#include "uiDraw.h"

class Lander
{
private:
	Point location;
public:
	Lander();

	Point getPoint() const;
	Velocity getVelocity() const;

	bool isAlive();
	bool isLanded();
	int getFuel();
	bool canThrust();


	void setLanded(bool);
	void setAlive(bool);
	void setFuel(int);

	void applyGravity(float);
	void applyThrustLeft();
	void applyThrustRight();
	void applyThrustBottom();

	void advance();
	void draw();
};