/***********************************************************************
* Header File:
*    Velocity : Things related to the velocity of the lander
* Author:
*    Alec Otterson
* Summary:
*    Everything we need to know about the velocity of the lander.
************************************************************************/

#pragma once

#include <iostream>

class Velocity
{
public:
	Velocity();
	Velocity(float, float);

	float getDx();
	float getDy();
	
	void setDx(float);
	void setDy(float);
};

