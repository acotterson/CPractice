#include "lander.h"

Lander::Lander()
{
}

Point Lander::getPoint() const
{
	return Point();
}

Velocity Lander::getVelocity() const
{
	return Velocity();
}

bool Lander::isAlive()
{
	return false;
}

bool Lander::isLanded()
{
	return false;
}

int Lander::getFuel()
{
	return 0;
}

bool Lander::canThrust()
{
	return false;
}

void Lander::setLanded(bool)
{
}

void Lander::setAlive(bool)
{
}

void Lander::setFuel(int)
{
}

void Lander::applyGravity(float)
{
}

void Lander::applyThrustLeft()
{
}

void Lander::applyThrustRight()
{
}

void Lander::applyThrustBottom()
{
}

void Lander::advance()
{
}

void Lander::draw()
{
	drawLander(location);
}