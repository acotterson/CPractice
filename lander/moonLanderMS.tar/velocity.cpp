#include "velocity.h"

Velocity::Velocity()
{
}

Velocity::Velocity(float, float)
{
}

float Velocity::getDx()
{
	return 0.0f;
}

float Velocity::getDy()
{
	return 0.0f;
}

void Velocity::setDx(float)
{
}

void Velocity::setDy(float)
{
}
